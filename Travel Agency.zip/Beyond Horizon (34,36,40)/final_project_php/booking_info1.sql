-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jun 06, 2024 at 05:02 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `login`
--

-- --------------------------------------------------------

--
-- Table structure for table `booking_info1`
--

CREATE TABLE `booking_info1` (
  `id` int(100) NOT NULL,
  `name` text NOT NULL,
  `email` varchar(255) NOT NULL,
  `number` int(100) NOT NULL,
  `departure_date` date NOT NULL,
  `trip_type` text NOT NULL,
  `destination` text NOT NULL,
  `package` text NOT NULL,
  `hear` text NOT NULL,
  `transaction` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `booking_info1`
--

INSERT INTO `booking_info1` (`id`, `name`, `email`, `number`, `departure_date`, `trip_type`, `destination`, `package`, `hear`, `transaction`) VALUES
(2, 'nishat', 'n@gmail.com', 132, '2024-02-12', 'business', '', '', 'fb', 'kfjhskdf'),
(3, 'nishat', 'n@gmail.com', 132, '2024-02-12', 'business', '', '', 'fb', 'kfjhskdf'),
(4, 'rafi', 'rafi@gmai.com', 65, '2024-05-28', 'pleasure', '', '', 'ts', 'uysud'),
(5, 'a', 'a@gmail', 123, '2024-05-18', 'business', '', '', 'fb', 'fhishdg'),
(6, 'Nishat', 'armybrity@gmail.com', 123, '2024-05-23', 'business', '', '', 'fb', 'ash'),
(7, 'nishat', 'armybrity@gmail.com', 12, '2024-05-23', 'business', '', '', 'fb', 'sdf'),
(8, 'sdf', 'armybrity@gmail.com', 123, '2024-05-31', 'business', 'Nikli', '', '', 'nbmn'),
(9, 'sdg', 'armybrity@gmail.com', 62, '2024-05-09', 'business', 'shatgombuj', 'Package 01 (5K BDT)', '', 'dsfg'),
(10, 'sdg', 'armybrity@gmail.com', 62, '2024-05-09', 'business', 'shatgombuj', 'Package 01 (5K BDT)', '', 'dsfg'),
(11, 'sdg', 'armybrity@gmail.com', 62, '2024-05-09', 'business', 'shatgombuj', 'Package 01 (5K BDT)', '', 'dsfg'),
(12, 'sdg', 'armybrity@gmail.com', 62, '2024-05-09', 'business', 'shatgombuj', 'Package 01 (5K BDT)', '', 'dsfg'),
(13, 'sdg', 'armybrity@gmail.com', 62, '2024-05-09', 'business', 'shatgombuj', 'Package 01 (5K BDT)', '', 'dsfg'),
(14, 'sdg', 'armybrity@gmail.com', 62, '2024-05-09', 'business', 'shatgombuj', 'Package 01 (5K BDT)', '', 'dsfg'),
(15, 'sdg', 'armybrity@gmail.com', 62, '2024-05-09', 'business', 'shatgombuj', 'Package 01 (5K BDT)', '', 'dsfg'),
(16, 'sdg', 'armybrity@gmail.com', 62, '2024-05-09', 'business', 'shatgombuj', 'Package 01 (5K BDT)', '', 'dsfg'),
(17, 'Sadman', 'armybrity@gmail.com', 123456, '2024-05-29', 'business', 'sundarban', 'Package 02 (3.5K BDT)', 'fb', 'sdhjfljhs'),
(18, 'Nishat', 'armybrity@gmail.com', 123456, '2024-05-23', 'pleasure', 'sajek valley', 'Package 01 (5K BDT)', 'insta', '123456sdf'),
(19, 'nush', 'nushrat.jahan6566@gmail.com', 8387483, '2024-05-29', 'pleasure', 'jaflong', 'Package 01 (5K BDT)', 'fdedrf', '6767'),
(20, 'nuzhat', 'armybrity@gmail.com', 123, '2024-05-24', 'business', 'shatgombuj Mosque', 'Package 01 (5K BDT)', 'fb', '123'),
(21, 'Nishat', 'nishatnuzhat034@gmail.com', 123, '2024-06-07', 'business', 'coxsbazar', 'Package 01 (5K BDT)', 'instagram', '123456'),
(22, 'nush', 'armybrity@gmail.com', 1767, '2024-06-15', 'business', 'shatgombuj Mosque', 'Package 02 (3.5K BDT)', 'gy', '878');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `booking_info1`
--
ALTER TABLE `booking_info1`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `booking_info1`
--
ALTER TABLE `booking_info1`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
